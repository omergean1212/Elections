package Model;

import java.util.Scanner;

//Interface of the menu that supports GUI
public interface Electable {
	// case 1
	public static void addKalpi(Elections useBehirot) {

	}

	// case2
	public static void CreateCitizen(Elections usebhirot) {

	}

	// case 3
	public static void CreateMiflaga(Elections useBehirot) {

	}

	// case 4
	public static void addCandidate(Elections useBehirot) throws Exception {

	}

	// case 5
	public static void showAllKalpiot(Elections useBehirot) {

	}

	// case 6
	public static void showAllCitizen(Elections useBehirot) {

	}

	// case 7
	public static void showAllMiglagot(Elections useBehirot) {

	}

	// case 8
	public static void behirot(Elections useBehirot, Scanner scan) {

	}

	// case 9
	public static void electionResults(Elections useBehirot) {

	}

}

package Model;

public interface Sickable {

	public int getNumOfDaysSick();
}
